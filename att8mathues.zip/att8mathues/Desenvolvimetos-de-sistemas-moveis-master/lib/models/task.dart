// Modelo de tarefa para SQLite
