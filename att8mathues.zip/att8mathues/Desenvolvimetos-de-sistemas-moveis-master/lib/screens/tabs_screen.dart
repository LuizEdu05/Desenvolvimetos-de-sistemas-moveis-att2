import 'package:flutter/material.dart';
import 'theme_tab.dart';
import 'tasks_tab.dart';
import 'firestore_tab.dart';
import 'supabase_tab.dart';
import 'compare_tab.dart';

class TabsScreen extends StatefulWidget {
  final Function(bool) onToggleTheme;
  final bool isDark;
  TabsScreen({required this.onToggleTheme, required this.isDark});

  @override
  _TabsScreenState createState() => _TabsScreenState();
}

class _TabsScreenState extends State<TabsScreen> {
  int _selectedIndex = 0;
  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      ThemeTab(onToggleTheme: widget.onToggleTheme, isDark: widget.isDark),
      TasksTab(),
      FirestoreTab(),
      SupabaseTab(),
      CompareTab(),
    ];
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.brightness_6), label: "Tema"),
          BottomNavigationBarItem(icon: Icon(Icons.task), label: "Tarefas"),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: "Usuários"),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: "Produtos"),
          BottomNavigationBarItem(icon: Icon(Icons.cloud), label: "Local vs Nuvem"),
        ],
      ),
    );
  }
}
