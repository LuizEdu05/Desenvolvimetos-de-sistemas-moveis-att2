import 'package:flutter/material.dart';

class ThemeTab extends StatelessWidget {
  final Function(bool) onToggleTheme;
  final bool isDark;
  ThemeTab({required this.onToggleTheme, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SwitchListTile(
        title: Text("Tema escuro"),
        value: isDark,
        onChanged: onToggleTheme,
      ),
    );
  }
}
