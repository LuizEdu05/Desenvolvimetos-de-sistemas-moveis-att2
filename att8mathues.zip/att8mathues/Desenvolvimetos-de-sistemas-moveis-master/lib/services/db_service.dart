// SQLite CRUD service
