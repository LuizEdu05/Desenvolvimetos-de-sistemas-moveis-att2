// Firebase Firestore service
