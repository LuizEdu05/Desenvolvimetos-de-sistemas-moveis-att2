// Secure storage service
