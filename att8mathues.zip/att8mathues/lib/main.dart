import 'package:flutter/material.dart';
import 'screens/tabs_screen.dart';
import 'services/theme_service.dart';
import 'services/db_service.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await DBService().init();
  await ThemeService().init();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isDark = false;

  @override
  void initState() {
    super.initState();
    ThemeService().isDark().then((v) {
      setState(() {
        _isDark = v;
      });
    });
  }

  void _toggleTheme(bool value) async {
    await ThemeService().setDark(value);
    setState(() => _isDark = value);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Plataforma Completa',
      theme: _isDark ? ThemeData.dark() : ThemeData.light(),
      home: TabsScreen(
        onToggleTheme: _toggleTheme,
        isDark: _isDark,
      ),
    );
  }
}
