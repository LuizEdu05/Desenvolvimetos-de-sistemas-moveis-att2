import 'package:flutter/material.dart';

class CompareTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Comparação Local vs Nuvem"));
  }
}
