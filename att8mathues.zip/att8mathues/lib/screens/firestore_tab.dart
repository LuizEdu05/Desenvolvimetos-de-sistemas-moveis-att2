import 'package:flutter/material.dart';

class FirestoreTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Cadastro de Usuários - Firestore"));
  }
}
