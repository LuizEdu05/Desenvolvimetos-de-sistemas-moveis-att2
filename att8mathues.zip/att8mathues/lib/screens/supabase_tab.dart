import 'package:flutter/material.dart';

class SupabaseTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Lista de Produtos - Supabase"));
  }
}
