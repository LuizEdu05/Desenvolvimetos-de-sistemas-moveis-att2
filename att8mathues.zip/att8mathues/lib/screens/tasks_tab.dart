import 'package:flutter/material.dart';

class TasksTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("CRUD SQLite de Tarefas"));
  }
}
