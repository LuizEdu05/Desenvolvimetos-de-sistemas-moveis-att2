// Theme service usando SharedPreferences
