# QuickOrder - Projeto de telas (Flutter) — Versão Avançada

## Como executar
1. `flutter pub get`
2. `flutter run`

## Recursos extras implementados
- **Tema escuro salvo** com `shared_preferences` (`ThemePrefs` em `lib/services/theme_prefs.dart`). Tela de exemplo: `SettingsScreen`.
- **Token seguro** com `flutter_secure_storage` (`SecureToken` em `lib/services/secure_token.dart`). Gerenciar em `SettingsScreen`.
- **CRUD SQLite** para tarefas (`TasksDB` e `Task` em `lib/services/tasks_db.dart`). Tela: `TasksScreen`.
- **Cadastro de usuários no Firestore** (`FirestoreService`). Tela: `FirestoreRegisterScreen`.
  > Requer configuração do Firebase (google-services.json, etc.). Sem config, o código faz no-op.
- **Lista de produtos no Supabase** (`SupaService`). Tela: `SupabaseProductsScreen`.
  > Requer `SupaService.init(url, anonKey)` em `main.dart`.
- **DFD (Data Flow Diagram)** do app em `assets/docs/dfd.png`.
- **Comparativo Local vs Nuvem** em `README` (abaixo).

## Atalhos no app (Home)
- Botões para abrir Configurações, Tarefas (SQLite), Cadastro Firestore e Produtos Supabase.

## Configurações necessárias (opcional)
### Firebase
- Adicione os arquivos de configuração do Firebase ao projeto e chame `Firebase.initializeApp()` (já há `ensureInitialized()` no serviço).
### Supabase
- Inicialize antes de listar produtos:
```dart
import 'services/supabase_service.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupaService.init(url: 'https://YOUR-PROJECT.supabase.co', anonKey: 'YOUR-ANON-KEY');
  runApp(QuickOrderApp());
}
```

## Comparativo Local vs Nuvem (prós e contras)
**Local (SharedPreferences, SecureStorage, SQLite)**
- **Prós:** Offline, rápido, simples, sem custos de nuvem, privacidade local.
- **Contras:** Sem sincronização entre dispositivos, backup manual, limites de espaço/consulta, risco de perda ao reinstalar app.

**Nuvem (Firestore, Supabase)**
- **Prós:** Sincroniza e compartilha dados, backups/alta disponibilidade, segurança gerenciável (Rules/Policies), escalabilidade, integrações.
- **Contras:** Precisa de internet, custo conforme uso, configuração e segurança mais complexas, dependência de terceiros.

## DFD
Veja `assets/docs/dfd.png` para o diagrama de fluxo de dados.
