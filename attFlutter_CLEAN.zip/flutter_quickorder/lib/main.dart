import 'package:flutter/material.dart';
import 'app_theme.dart';
import 'routes.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Caso vá usar Supabase de verdade:
  // await SupaService.init(url: 'https://YOUR.supabase.co', anonKey: 'YOUR-ANON-KEY');
  runApp(QuickOrderApp());
}

class QuickOrderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QuickOrder',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      initialRoute: Routes.splash,
      onGenerateRoute: Routes.generate,
      debugShowCheckedModeBanner: false,
    );
  }
}
