class Restaurant {
  final String name;
  final String subtitle;
  final double rating;
  final String image;
  Restaurant({required this.name, required this.subtitle, required this.rating, required this.image});
}

class Product {
  final String name;
  final String description;
  final double price;
  final String image;
  Product({required this.name, required this.description, required this.price, required this.image});
}

final sampleRestaurants = [
  Restaurant(name: 'Sabor & Cia', subtitle: 'Comida caseira', rating: 4.6, image: 'assets/images/salad.png'),
  Restaurant(name: 'Pizza Prime', subtitle: 'Pizzas artesanais', rating: 4.4, image: 'assets/images/pizza.png'),
  Restaurant(name: 'Burger Station', subtitle: 'Burgers e fritas', rating: 4.5, image: 'assets/images/burger.png'),
];

final sampleProducts = [
  Product(name: 'X-Burguer', description: 'Carne, queijo e alface', price: 22.50, image: 'assets/images/burger.png'),
  Product(name: 'Pizza Calabresa', description: 'Massa fina, muita calabresa', price: 48.00, image: 'assets/images/pizza.png'),
  Product(name: 'Combo Sushi', description: 'Salmão, atum e vegetais', price: 56.00, image: 'assets/images/sushi.png'),
  Product(name: 'Salada Caesar', description: 'Alface, frango, molho caesar', price: 18.00, image: 'assets/images/salad.png'),
  Product(name: 'Cheesecake', description: 'Sobremesa cremosa com calda', price: 19.90, image: 'assets/images/dessert.png'),
];
