import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      {'name': 'X-Burguer', 'qty': 1, 'price': 22.50},
      {'name': 'Cheesecake', 'qty': 1, 'price': 19.90},
    ];
    double total = items.fold(0, (s, e) => s + (e['price'] as double) * (e['qty'] as int));

    return Scaffold(
      appBar: simpleAppBar('Carrinho'),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Expanded(
              child: ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (_, i) => ListTile(
                  title: Text(items[i]['name'] as String),
                  subtitle: Text('Quantidade: ${items[i]['qty']}'),
                  trailing: Text('R\$ ${(items[i]['price'] as double).toStringAsFixed(2)}'),
                ),
              ),
            ),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('R\$ ${total.toStringAsFixed(2)}')],
            ),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.checkout), child: const Text('Finalizar pedido')))
          ],
        ),
      ),
    );
  }
}
