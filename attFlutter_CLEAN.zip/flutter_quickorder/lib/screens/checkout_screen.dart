import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class CheckoutScreen extends StatefulWidget {
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  String method = 'card';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Checkout'),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Endereço de entrega', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const TextField(decoration: InputDecoration(hintText: 'Rua, número, complemento')),
            const SizedBox(height: 12),
            const Text('Forma de pagamento', style: TextStyle(fontWeight: FontWeight.bold)),
            RadioListTile(value: 'card', groupValue: method, onChanged: (v) => setState(() => method = v.toString()), title: const Text('Cartão de crédito')),
            RadioListTile(value: 'pix', groupValue: method, onChanged: (v) => setState(() => method = v.toString()), title: const Text('PIX')),
            const Spacer(),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/rating'), child: const Text('Confirmar pagamento')))
          ],
        ),
      ),
    );
  }
}
