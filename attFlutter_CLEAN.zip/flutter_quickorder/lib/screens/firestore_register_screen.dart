import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../services/firestore_service.dart';

class FirestoreRegisterScreen extends StatefulWidget {
  @override
  State<FirestoreRegisterScreen> createState() => _FirestoreRegisterScreenState();
}

class _FirestoreRegisterScreenState extends State<FirestoreRegisterScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  String status = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Cadastro (Firestore)'),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: name, decoration: const InputDecoration(hintText: 'Nome')),
            const SizedBox(height: 12),
            TextField(controller: email, decoration: const InputDecoration(hintText: 'Email')),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: () async {
              setState(() => status = 'Enviando...');
              await FirestoreService.createUser(name.text, email.text);
              setState(() => status = 'Cadastro enviado (verifique o Firestore se configurado).');
            }, child: const Text('Cadastrar')),
            const SizedBox(height: 12),
            Text(status),
          ],
        ),
      ),
    );
  }
}
