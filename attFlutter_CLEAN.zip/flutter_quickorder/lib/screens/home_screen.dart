import 'package:flutter/material.dart';
import '../models/sample_models.dart';
import '../widgets/restaurant_card.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Restaurantes'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar restaurantes')),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.settings), child: const Text('Configurações')),
              ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.tasks), child: const Text('Tarefas')),
              ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.fsRegister), child: const Text('Firestore')),
              ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.supaProducts), child: const Text('Supabase')),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: sampleRestaurants.length,
              itemBuilder: (_, i) => RestaurantCard(
                restaurant: sampleRestaurants[i],
                onTap: () => Navigator.pushNamed(context, Routes.restaurant, arguments: sampleRestaurants[i]),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, Routes.cart),
        child: const Icon(Icons.shopping_cart),
      ),
    );
  }
}
