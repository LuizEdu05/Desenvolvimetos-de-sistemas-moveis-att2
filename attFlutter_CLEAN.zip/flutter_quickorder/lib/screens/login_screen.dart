import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../widgets/app_input.dart';
import '../widgets/app_button.dart';
import '../routes.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Login'),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const AppInput(hint: 'Email', icon: Icons.email),
            const SizedBox(height: 12),
            const AppInput(hint: 'Senha', icon: Icons.lock, obscure: true),
            const SizedBox(height: 20),
            AppButton(label: 'Entrar', onPressed: () => Navigator.pushReplacementNamed(context, Routes.home)),
            const SizedBox(height: 12),
            TextButton(onPressed: () => Navigator.pushNamed(context, Routes.signup), child: const Text('Criar conta')),
          ],
        ),
      ),
    );
  }
}
