import 'package:flutter/material.dart';
import '../models/sample_models.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class ProductScreen extends StatelessWidget {
  final Product product;
  ProductScreen({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar(product.name),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(product.image, width: double.infinity, height: 220, fit: BoxFit.cover),
            ),
            const SizedBox(height: 12),
            Text(product.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(product.description, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            Text('R\$ ${product.price.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, Routes.cart), child: const Text('Adicionar ao carrinho')),
            )
          ],
        ),
      ),
    );
  }
}
