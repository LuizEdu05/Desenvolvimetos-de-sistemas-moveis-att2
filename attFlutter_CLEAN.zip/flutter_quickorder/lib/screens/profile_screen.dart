import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Perfil'),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            CircleAvatar(radius: 44, backgroundColor: const Color(0xFF4A90E2), child: Image.asset('assets/images/logo.png', width: 36, height: 36)),
            const SizedBox(height: 12),
            const Text('João da Silva', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const ListTile(title: Text('Meus pedidos'), trailing: Icon(Icons.chevron_right)),
            const ListTile(title: Text('Endereços'), trailing: Icon(Icons.chevron_right)),
            const ListTile(title: Text('Formas de pagamento'), trailing: Icon(Icons.chevron_right)),
            const Spacer(),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () {}, child: const Text('Sair')))
          ],
        ),
      ),
    );
  }
}
