import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class RatingScreen extends StatefulWidget {
  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int rating = 4;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Avaliar pedido'),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            const Text('Como foi sua experiência?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) => IconButton(
                onPressed: () => setState(() => rating = i + 1),
                icon: Icon(Icons.star, size: 36, color: i < rating ? Colors.amber : Colors.grey),
              )),
            ),
            const SizedBox(height: 12),
            const TextField(maxLines: 4, decoration: InputDecoration(hintText: 'Deixe um comentário...')),
            const Spacer(),
            SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/profile'), child: const Text('Enviar avaliação')))
          ],
        ),
      ),
    );
  }
}
