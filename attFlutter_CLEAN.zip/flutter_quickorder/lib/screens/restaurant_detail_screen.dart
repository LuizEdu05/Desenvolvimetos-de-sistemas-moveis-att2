import 'package:flutter/material.dart';
import '../models/sample_models.dart';
import '../widgets/product_card.dart';
import '../widgets/app_bar_simple.dart';
import '../routes.dart';

class RestaurantDetailScreen extends StatelessWidget {
  final Restaurant restaurant;
  RestaurantDetailScreen({required this.restaurant});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar(restaurant.name),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16)),
            child: Image.asset(restaurant.image, width: double.infinity, height: 180, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(restaurant.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  Text(restaurant.subtitle),
                ]),
                Row(children: const [Icon(Icons.star, color: Colors.amber), SizedBox(width: 6), Text('4.5')])
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('Cardápio', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: sampleProducts.length,
              itemBuilder: (_, i) => ProductCard(
                product: sampleProducts[i],
                onAdd: () => Navigator.pushNamed(context, Routes.cart),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
