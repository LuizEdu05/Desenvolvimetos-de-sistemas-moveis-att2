import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../services/theme_prefs.dart';
import '../services/secure_token.dart';

class SettingsScreen extends StatefulWidget {
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool dark = false;
  String? token;
  final controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final isDark = await ThemePrefs.getDarkMode();
    final tk = await SecureToken.read();
    setState(() {
      dark = isDark;
      token = tk;
      controller.text = tk ?? '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Configurações'),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SwitchListTile(
              title: const Text('Tema escuro (salvo)'),
              value: dark,
              onChanged: (v) async {
                setState(() => dark = v);
                await ThemePrefs.setDarkMode(v);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tema salvo em SharedPreferences')));
              },
            ),
            const SizedBox(height: 16),
            const Text('Token seguro (Secure Storage)'),
            const SizedBox(height: 8),
            TextField(controller: controller, decoration: const InputDecoration(hintText: 'Digite um token para salvar')),
            const SizedBox(height: 8),
            Row(children: [
              ElevatedButton(onPressed: () async {
                await SecureToken.save(controller.text);
                setState(() => token = controller.text);
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Token salvo com segurança')));
              }, child: const Text('Salvar')),
              const SizedBox(width: 12),
              OutlinedButton(onPressed: () async {
                await SecureToken.delete();
                setState(() { token = null; controller.text = ''; });
              }, child: const Text('Excluir')),
            ]),
            const SizedBox(height: 12),
            Text('Token atual: ${token ?? "(nenhum)"}'),
          ],
        ),
      ),
    );
  }
}
