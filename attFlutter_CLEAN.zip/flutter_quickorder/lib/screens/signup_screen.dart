import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../widgets/app_input.dart';
import '../widgets/app_button.dart';
import '../routes.dart';

class SignupScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Cadastro'),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: const [
              AppInput(hint: 'Nome', icon: Icons.person),
              SizedBox(height: 12),
              AppInput(hint: 'Email', icon: Icons.email),
              SizedBox(height: 12),
              AppInput(hint: 'Telefone', icon: Icons.phone),
              SizedBox(height: 12),
              AppInput(hint: 'Senha', icon: Icons.lock, obscure: true),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: AppButton(label: 'Registrar', onPressed: () => Navigator.pushReplacementNamed(context, Routes.home)),
      ),
    );
  }
}
