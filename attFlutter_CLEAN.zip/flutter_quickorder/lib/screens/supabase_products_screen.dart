import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../services/supabase_service.dart';

class SupabaseProductsScreen extends StatefulWidget {
  @override
  State<SupabaseProductsScreen> createState() => _SupabaseProductsScreenState();
}

class _SupabaseProductsScreenState extends State<SupabaseProductsScreen> {
  List<Map<String, dynamic>> products = [];
  String notice = 'Configure o Supabase para listar produtos.';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await SupaService.listProducts();
    if (list.isNotEmpty) {
      setState(() { products = list; notice = ''; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Produtos (Supabase)'),
      body: products.isEmpty ? Center(child: Text(notice)) : ListView.separated(
        itemCount: products.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (_, i) => ListTile(
          title: Text(products[i]['name']?.toString() ?? 'Sem nome'),
          subtitle: Text('Preço: R\$ ${products[i]['price'] ?? '-'}'),
        ),
      ),
    );
  }
}
