import 'package:flutter/material.dart';
import '../widgets/app_bar_simple.dart';
import '../services/tasks_db.dart';

class TasksScreen extends StatefulWidget {
  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  List<Task> tasks = [];
  final controller = TextEditingController();

  Future<void> _load() async {
    tasks = await TasksDB.all();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: simpleAppBar('Tarefas (SQLite)'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Nova tarefa...'))),
                const SizedBox(width: 8),
                ElevatedButton(onPressed: () async {
                  if (controller.text.trim().isEmpty) return;
                  await TasksDB.insert(Task(title: controller.text.trim()));
                  controller.clear();
                  _load();
                }, child: const Text('Adicionar')),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              itemCount: tasks.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final t = tasks[i];
                return ListTile(
                  leading: Checkbox(
                    value: t.done,
                    onChanged: (v) async {
                      t.done = v ?? false;
                      await TasksDB.update(t);
                      _load();
                    },
                  ),
                  title: Text(t.title, style: TextStyle(decoration: t.done ? TextDecoration.lineThrough : null)),
                  trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
                    if (t.id != null) await TasksDB.delete(t.id!);
                    _load();
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
