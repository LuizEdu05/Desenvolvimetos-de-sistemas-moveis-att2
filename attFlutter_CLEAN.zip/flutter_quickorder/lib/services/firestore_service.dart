import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

class FirestoreService {
  static bool _initialized = false;
  static Future<void> ensureInitialized() async {
    if (_initialized) return;
    try {
      await Firebase.initializeApp();
      _initialized = true;
    } catch (e) {
      // ignore if not configured
    }
  }

  static Future<void> createUser(String name, String email) async {
    await ensureInitialized();
    try {
      await FirebaseFirestore.instance.collection('users').add({
        'name': name,
        'email': email,
        'createdAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      // no-op in demo
    }
  }
}
