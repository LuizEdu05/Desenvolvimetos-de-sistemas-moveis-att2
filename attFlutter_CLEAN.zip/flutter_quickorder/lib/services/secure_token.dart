import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureToken {
  static const _key = 'auth_token';
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  static Future<void> save(String token) => _storage.write(key: _key, value: token);
  static Future<String?> read() => _storage.read(key: _key);
  static Future<void> delete() => _storage.delete(key: _key);
}
