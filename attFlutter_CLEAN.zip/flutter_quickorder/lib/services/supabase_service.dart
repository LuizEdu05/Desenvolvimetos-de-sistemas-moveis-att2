import 'package:supabase_flutter/supabase_flutter.dart';

class SupaService {
  static bool _init = false;
  static Future<void> init({required String url, required String anonKey}) async {
    if (_init) return;
    await Supabase.initialize(url: url, anonKey: anonKey);
    _init = true;
  }

  static Future<List<Map<String, dynamic>>> listProducts() async {
    if (!_init) return [];
    final res = await Supabase.instance.client.from('products').select<List<Map<String, dynamic>>>();
    return res;
  }
}
