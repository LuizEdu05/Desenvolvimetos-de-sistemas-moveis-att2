import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

class Task {
  int? id;
  String title;
  bool done;
  Task({this.id, required this.title, this.done = false});

  Map<String, dynamic> toMap() => {'id': id, 'title': title, 'done': done ? 1 : 0};
  static Task fromMap(Map<String, dynamic> m) => Task(id: m['id'] as int?, title: m['title'] as String, done: (m['done'] as int) == 1);
}

class TasksDB {
  static Database? _db;
  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'quickorder_tasks.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, v) async {
      await db.execute('CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, done INTEGER)');
    });
    return _db!;
  }

  static Future<List<Task>> all() async {
    final db = await _open();
    final rows = await db.query('tasks', orderBy: 'id DESC');
    return rows.map((e) => Task.fromMap(e)).toList();
  }

  static Future<int> insert(Task t) async {
    final db = await _open();
    return db.insert('tasks', t.toMap());
  }

  static Future<int> update(Task t) async {
    final db = await _open();
    return db.update('tasks', t.toMap(), where: 'id = ?', whereArgs: [t.id]);
  }

  static Future<int> delete(int id) async {
    final db = await _open();
    return db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
}
