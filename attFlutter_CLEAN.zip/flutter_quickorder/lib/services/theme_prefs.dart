import 'package:shared_preferences/shared_preferences.dart';

class ThemePrefs {
  static const _kDarkMode = 'dark_mode';
  static Future<bool> getDarkMode() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getBool(_kDarkMode) ?? false;
  }
  static Future<void> setDarkMode(bool value) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(_kDarkMode, value);
  }
}
