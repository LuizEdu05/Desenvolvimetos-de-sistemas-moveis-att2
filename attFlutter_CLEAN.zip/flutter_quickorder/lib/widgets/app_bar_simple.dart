import 'package:flutter/material.dart';

PreferredSizeWidget simpleAppBar(String title) { return AppBar(title: Text(title)); }
