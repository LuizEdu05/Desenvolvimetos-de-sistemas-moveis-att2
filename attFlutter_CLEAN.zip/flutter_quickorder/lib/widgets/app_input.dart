import 'package:flutter/material.dart';

class AppInput extends StatelessWidget { final String hint; final IconData? icon; final bool obscure; const AppInput({super.key, required this.hint, this.icon, this.obscure=false}); @override Widget build(BuildContext context){ return TextField(obscureText: obscure, decoration: InputDecoration(hintText: hint, prefixIcon: icon!=null?Icon(icon):null)); }}
