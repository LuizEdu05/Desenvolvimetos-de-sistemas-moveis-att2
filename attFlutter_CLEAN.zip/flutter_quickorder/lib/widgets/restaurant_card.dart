import 'package:flutter/material.dart';
import '../models/sample_models.dart';
import 'app_card.dart';

class RestaurantCard extends StatelessWidget { final Restaurant restaurant; final VoidCallback? onTap; const RestaurantCard({super.key, required this.restaurant, this.onTap}); @override Widget build(BuildContext context){ return AppCard(onTap:onTap, child: Row(children:[ ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset(restaurant.image, width:80, height:80, fit: BoxFit.cover)), const SizedBox(width:12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text(restaurant.name, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height:4), Text(restaurant.subtitle, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Color(0xFF666666))), const SizedBox(height:6), Row(children: const [Icon(Icons.star, size:16, color: Colors.amber), SizedBox(width:4), Text('4.5')]), ])), const Icon(Icons.chevron_right) ])); }}
